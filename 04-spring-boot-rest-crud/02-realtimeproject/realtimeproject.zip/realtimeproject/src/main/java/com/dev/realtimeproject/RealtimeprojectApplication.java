package com.dev.realtimeproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealtimeprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealtimeprojectApplication.class, args);
	}

}
