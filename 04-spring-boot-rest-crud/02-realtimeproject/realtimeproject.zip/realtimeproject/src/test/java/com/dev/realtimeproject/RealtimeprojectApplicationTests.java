package com.dev.realtimeproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealtimeprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
